#include <iostream>
#include "rectangle.h"
using namespace std;

int main()
{
    Rectangle r1;
    Rectangle r2(3,3);
    Rectangle r3;

    cout << "Area of r1: " << r1.area() << endl;
    cout << "Area of r2: " << r2.area() << endl;
    cout << "Area of r3: " << r3.area() << endl;

    if(r1.equal(r2))
        cout << "r1 is equal to r2" << endl;
    else
        cout << "r1 is not equal to r2" << endl;

    if(r1.equal(r3))
        cout << "r1 is equal to r3" << endl;
    else
        cout << "r1 is not equal to r3" << endl;


}
