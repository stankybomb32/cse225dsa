#include "Rectangle.h"

Rectangle::Rectangle()
{
    length = 1;
    breadth = 1;
}

Rectangle::Rectangle(int l, int b)
{
    length = l;
    breadth = b;
}

int Rectangle::area()
{
    return length*breadth;
}

bool Rectangle::equal(Rectangle r)
{
    if(this->length*this->breadth == r.length*r.breadth)
        return true;
    else
        return false;
}
