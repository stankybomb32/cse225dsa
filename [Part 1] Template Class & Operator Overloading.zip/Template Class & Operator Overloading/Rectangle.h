#ifndef RECTANGLE_H_INCLUDED
#define RECTANGLE_H_INCLUDED
class Rectangle
{
private:
    int length, breadth;
public:
    Rectangle();
    Rectangle(int l, int b);
    int area();
    bool equal(Rectangle r);
};





#endif // RECTANGLE_H_INCLUDED
